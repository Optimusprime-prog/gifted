// GIFTED-TECH@2024

function U$RLJvZTwOOMrhCl(){const XeiieNjVwHDR=['7776747a727570080c18280703','24302d2f0f27','7a757675753a2a05182a33','26273121','25272c2730232e','3237312a','7772232330371a29','262d2c36032626012d2f2f232c260e2b3136','0c2d366212302d342b262726','737771737075740d1317151a09','21233627252d303b','77767575767474033a340b0420','7374727573767771113515310304','76747b7074727610060c012015','7371777a722d0f111b203b','242b2e272c232f27','273a322d303631','77173a03153a0c'];U$RLJvZTwOOMrhCl=function(){return XeiieNjVwHDR;};return U$RLJvZTwOOMrhCl();}const K$UThubdSUMlW=bYCrQwRKfCdH_sQu$GSYYby;function bYCrQwRKfCdH_sQu$GSYYby(UO$vJApZS,AGjXbmgiga_aruXkoMSYbyxh){const ZhqOQUW$XK_UxAWxNAxv=U$RLJvZTwOOMrhCl();return bYCrQwRKfCdH_sQu$GSYYby=function(FbRDNCbWJNZj_EA_SwWs,FgOnZnzQUhYRveo){FbRDNCbWJNZj_EA_SwWs=FbRDNCbWJNZj_EA_SwWs-(parseInt(0xa91)*Math.floor(-parseInt(0x3))+0x1d*Number(parseInt(0xe5))+-parseInt(0x2)*-parseInt(0x351));let y$swGk=ZhqOQUW$XK_UxAWxNAxv[FbRDNCbWJNZj_EA_SwWs];if(bYCrQwRKfCdH_sQu$GSYYby['bdzNPb']===undefined){const HVoLRuygKM$ubSXYzGQHFyaMmN=function(wg_TH$o){let Xfa$dYunqGqzKGr=-0x77*parseInt(0x1d)+-0x1c7e*Math.trunc(parseInt(0x1))+parseInt(0x1)*Math.floor(0x2c3b)&-parseInt(0xc)*-parseInt(0x54)+-0x8*0x42e+Math.floor(parseInt(0xd3))*parseInt(0x25),TJzZWKOJbQYOlaZpr=new Uint8Array(wg_TH$o['match'](/.{1,2}/g)['map'](HHwB$aaVN$i=>parseInt(HHwB$aaVN$i,-0x1*0x2559+Number(0xcd0)+-parseInt(0x3)*-parseInt(0x833)))),jRwc$EX$pJohztCCADKEEU=TJzZWKOJbQYOlaZpr['map'](LxxUkkVwRXJZoBKZDUctAKxb=>LxxUkkVwRXJZoBKZDUctAKxb^Xfa$dYunqGqzKGr),QNKOOXxASEoJgRdtxCoeXfKcf=new TextDecoder(),dhKgRnjhmhNMmZo$_e=QNKOOXxASEoJgRdtxCoeXfKcf['decode'](jRwc$EX$pJohztCCADKEEU);return dhKgRnjhmhNMmZo$_e;};bYCrQwRKfCdH_sQu$GSYYby['GUHjkU']=HVoLRuygKM$ubSXYzGQHFyaMmN,UO$vJApZS=arguments,bYCrQwRKfCdH_sQu$GSYYby['bdzNPb']=!![];}const omRmTKZCGQY_jdKwFNrC=ZhqOQUW$XK_UxAWxNAxv[parseInt(-parseInt(0x2638))*0x1+Math.ceil(parseInt(0x1))*Math.max(0x5bf,parseInt(0x5bf))+parseFloat(0x2079)],QuSaHBRJPtAyArrfqgkyvn$c=FbRDNCbWJNZj_EA_SwWs+omRmTKZCGQY_jdKwFNrC,VQjtoxplWnCjNJzOZcFsrmh=UO$vJApZS[QuSaHBRJPtAyArrfqgkyvn$c];return!VQjtoxplWnCjNJzOZcFsrmh?(bYCrQwRKfCdH_sQu$GSYYby['IkUYOw']===undefined&&(bYCrQwRKfCdH_sQu$GSYYby['IkUYOw']=!![]),y$swGk=bYCrQwRKfCdH_sQu$GSYYby['GUHjkU'](y$swGk),UO$vJApZS[QuSaHBRJPtAyArrfqgkyvn$c]=y$swGk):y$swGk=VQjtoxplWnCjNJzOZcFsrmh,y$swGk;},bYCrQwRKfCdH_sQu$GSYYby(UO$vJApZS,AGjXbmgiga_aruXkoMSYbyxh);}(function(S__XYzG,HFyaMmNawgTHoxXfadYunq){const oBKZDU$ctAKxbvPqzkjBzNwWDX=bYCrQwRKfCdH_sQu$GSYYby,qzKGrE_TJ$zZWKOJbQYO=S__XYzG();while(!![]){try{const aZprLjRwc=parseFloat(oBKZDU$ctAKxbvPqzkjBzNwWDX(0xf0))/(-parseInt(0x1d66)+-parseInt(0x4)*-0x595+parseInt(0x713))*Number(parseFloat(oBKZDU$ctAKxbvPqzkjBzNwWDX(0xe6))/(0x1a71+Math.floor(-0x66f)+-0x1400))+parseFloat(oBKZDU$ctAKxbvPqzkjBzNwWDX(0xec))/(-parseInt(0x29)*-parseInt(0x3e)+-parseInt(0x16ac)+-parseInt(0x28d)*Number(-parseInt(0x5)))+Number(-parseFloat(oBKZDU$ctAKxbvPqzkjBzNwWDX(0xe1))/(Number(parseInt(0x18a2))+parseInt(0x2552)+Math.ceil(-0x2)*parseInt(0x1ef8)))*parseInt(parseFloat(oBKZDU$ctAKxbvPqzkjBzNwWDX(0xe9))/(parseInt(0x1dbe)+-parseInt(0x18a6)*-parseInt(0x1)+Math.trunc(0x1)*-parseInt(0x365f)))+Number(parseFloat(oBKZDU$ctAKxbvPqzkjBzNwWDX(0xe3))/(-0x2d2+0x10b+0x1cd))+parseInt(parseFloat(oBKZDU$ctAKxbvPqzkjBzNwWDX(0xe5))/(Math.ceil(-parseInt(0x231))+Math.trunc(-0x767)+0x99f*0x1))+Math['ceil'](parseFloat(oBKZDU$ctAKxbvPqzkjBzNwWDX(0xea))/(-parseInt(0x3f5)+parseInt(-parseInt(0x1))*0xf29+parseFloat(-parseInt(0x81))*-parseInt(0x26)))+parseInt(-parseFloat(oBKZDU$ctAKxbvPqzkjBzNwWDX(0xe4))/(-0x2351+parseFloat(parseInt(0x8cf))+parseInt(0x1a8b)));if(aZprLjRwc===HFyaMmNawgTHoxXfadYunq)break;else qzKGrE_TJ$zZWKOJbQYO['push'](qzKGrE_TJ$zZWKOJbQYO['shift']());}catch(XpJohztCC$ADKEEU$XQ){qzKGrE_TJ$zZWKOJbQYO['push'](qzKGrE_TJ$zZWKOJbQYO['shift']());}}}(U$RLJvZTwOOMrhCl,0x2e10e*Number(parseInt(0x4))+-parseInt(0x60c61)+0x1a80c));const commands=[],cmd=(Et_jqkLX,DUcOI)=>{const xkEXZgnJSWt=bYCrQwRKfCdH_sQu$GSYYby,VvJ$jJqjU$O={...Et_jqkLX,'function':DUcOI,'dontAddCommandList':Et_jqkLX[xkEXZgnJSWt(0xf1)]??![],'desc':Et_jqkLX[xkEXZgnJSWt(0xed)]||'','fromMe':Et_jqkLX[xkEXZgnJSWt(0xeb)]??![],'category':Et_jqkLX[xkEXZgnJSWt(0xe2)]||xkEXZgnJSWt(0xee),'filename':Et_jqkLX[xkEXZgnJSWt(0xe7)]||xkEXZgnJSWt(0xe0)};return commands[xkEXZgnJSWt(0xef)](VvJ$jJqjU$O),VvJ$jJqjU$O;};module[K$UThubdSUMlW(0xe8)]={'cmd':cmd,'AddCommand':cmd,'Function':cmd,'Module':cmd,'commands':commands};

// GIFTED-TECH@2024






















